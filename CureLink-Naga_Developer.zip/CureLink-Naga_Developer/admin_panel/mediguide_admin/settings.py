# admin_panel/mediguide_admin/settings.py
# Django admin panel — shares the same PostgreSQL database as FastAPI

from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.getenv("SECRET_KEY", "django-insecure-change-this")
DEBUG      = os.getenv("DEBUG", "True") == "True"
ALLOWED_HOSTS = os.getenv("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")

INSTALLED_APPS = [
    "mediguide_admin.apps.MediguideAdminConfig",  # our custom admin
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "mediguide_admin.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "mediguide_admin" / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "mediguide_admin.wsgi.application"

# ── Database — same PostgreSQL as FastAPI ─────────────────
db_url = os.getenv("DATABASE_URL", "postgresql://mediguide:mediguide123@localhost:5432/mediguide_db")
# Parse the URL manually for Django
import re
m = re.match(r"postgresql://([^:]+):([^@]+)@([^:/]+):?(\d+)?/(.+)", db_url)
if m:
    DB_USER, DB_PASS, DB_HOST, DB_PORT, DB_NAME = m.groups()
    DB_PORT = DB_PORT or "5432"
else:
    DB_USER, DB_PASS, DB_HOST, DB_PORT, DB_NAME = "mediguide","mediguide123","localhost","5432","mediguide_db"

DATABASES = {
    "default": {
        "ENGINE":   "django.db.backends.postgresql",
        "NAME":     DB_NAME,
        "USER":     DB_USER,
        "PASSWORD": DB_PASS,
        "HOST":     DB_HOST,
        "PORT":     DB_PORT,
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE     = "Asia/Kolkata"
USE_I18N      = True
USE_TZ        = True

STATIC_URL   = "/static/"
STATIC_ROOT  = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ── Custom admin branding ─────────────────────────────────
ADMIN_SITE_HEADER  = "MediGuide India — Admin"
ADMIN_SITE_TITLE   = "MediGuide Admin"
ADMIN_INDEX_TITLE  = "Hospital Management Dashboard"